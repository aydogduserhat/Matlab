% (provide an explanation what this scripts does)
% This scripts is bug free version of original script given as a debugging
% task.
%
% Debugged by: (your name and surname)
%
% Task: 3-5
%

clear all;

% here we define our integrand
integrand = reallog( 1 + x ) / x;

% here we sample integrand
x = linspace(0, pi, 314);
h = pi/314;
y = integrand(x);

% here we integrate
I = integrate(y,h);